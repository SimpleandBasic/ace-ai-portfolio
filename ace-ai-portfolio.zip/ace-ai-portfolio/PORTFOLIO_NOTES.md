# Portfolio Editing Notes

## Best title options

AI Workflow Builder and Practical Systems Designer
Practical AI Builder for Small Teams
AI Systems Designer for Founders and Operators
Creative Operations and AI Workflow Builder

## Suggested public description

I help founders and small teams turn scattered ideas, operations, documents, apps, and daily workflows into practical AI powered systems.

## Projects to keep private

Levrynn
President's Office dashboard
Private reflections
Private audio memos
Private journal entries
Private business notes
Private Supabase databases

## Public demo idea

Create a separate guest demo with fake sample data only.

Recommended demo content:
1. Sample visual anchor card
2. Sample journal entry
3. Sample transcript
4. Sample voice memo placeholder
5. Sample filter group
6. No login required
7. No real database access
