const navToggle = document.querySelector(".nav-toggle");
const navLinks = document.querySelector("[data-nav-links]");
const themeToggle = document.querySelector("[data-theme-toggle]");
const yearEl = document.querySelector("[data-year]");
const copyButton = document.querySelector("[data-copy-email]");
const copyNote = document.querySelector("[data-copy-note]");
const modal = document.querySelector("[data-modal]");
const modalKicker = document.querySelector("[data-modal-kicker]");
const modalTitle = document.querySelector("[data-modal-title]");
const modalBody = document.querySelector("[data-modal-body]");
const modalList = document.querySelector("[data-modal-list]");
const modalClose = document.querySelector("[data-close-modal]");

const summaries = {
  levrynn: {
    kicker: "Private AI App",
    title: "Levrynn",
    body: "Levrynn is a private AI assisted reflection library. It is designed to help a person save important ideas as visual anchors, voice memos, journal entries, transcripts, and reviewable memories.",
    bullets: [
      "Transforms reflections and notes into organized review cards.",
      "Supports generated visual anchors, audio memos, transcripts, filters, and categories.",
      "Uses private database and storage patterns, with public demo content kept separate.",
      "Best public demo approach: fake sample data, sample images, and sample transcripts only."
    ]
  },
  hebrew: {
    kicker: "Learning App",
    title: "Hebrew Bible Study App",
    body: "The Hebrew Bible Study App helps users read Hebrew Scripture out loud with support under the Hebrew text rather than hiding the main reading experience inside a dashboard.",
    bullets: [
      "Hebrew reader with transliteration and English support.",
      "Clickable Hebrew words open deeper study cards.",
      "Phrase by phrase speaking practice supports repetition and active highlighting.",
      "Designed for Bible reading, pronunciation practice, and structured Hebrew learning."
    ]
  },
  shortcuts: {
    kicker: "Automation",
    title: "iOS Shortcuts and Voice Systems",
    body: "These workflows connect phone habits to AI systems so users can speak, capture, clean, and route information quickly.",
    bullets: [
      "Speech to text and dictation workflows.",
      "API connected Shortcut patterns for practical phone based tools.",
      "Daily weather and briefing automations.",
      "Message, notes, and task cleanup flows."
    ]
  },
  operations: {
    kicker: "Operations",
    title: "Coffee Operations and Product Testing",
    body: "AI supported business operations work focused on turning field notes, product tests, vendors, and team communication into clear next steps.",
    bullets: [
      "Coffee tasting and sampling templates.",
      "Vendor comparison summaries.",
      "Production planning support.",
      "Clear update messages and decision summaries for teams."
    ]
  }
};

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  if (themeToggle) {
    themeToggle.textContent = theme === "dark" ? "☾" : "☀︎";
  }
  localStorage.setItem("acePortfolioTheme", theme);
}

if (yearEl) {
  yearEl.textContent = new Date().getFullYear();
}

const savedTheme = localStorage.getItem("acePortfolioTheme");
const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
applyTheme(savedTheme || (prefersDark ? "dark" : "light"));

navToggle?.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("is-open");
  navToggle.setAttribute("aria-expanded", String(isOpen));
});

navLinks?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("is-open");
    navToggle?.setAttribute("aria-expanded", "false");
  });
});

themeToggle?.addEventListener("click", () => {
  const current = document.documentElement.dataset.theme || "light";
  applyTheme(current === "dark" ? "light" : "dark");
});

copyButton?.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText("streamdeckace@gmail.com");
    copyNote.textContent = "Copied.";
  } catch {
    copyNote.textContent = "Email: streamdeckace@gmail.com";
  }

  setTimeout(() => {
    copyNote.textContent = "";
  }, 2500);
});

document.querySelectorAll("[data-open-modal]").forEach((button) => {
  button.addEventListener("click", () => {
    const key = button.getAttribute("data-open-modal");
    const summary = summaries[key];

    if (!summary || !modal) return;

    modalKicker.textContent = summary.kicker;
    modalTitle.textContent = summary.title;
    modalBody.textContent = summary.body;
    modalList.innerHTML = "";

    summary.bullets.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      modalList.appendChild(li);
    });

    modal.showModal();
  });
});

modalClose?.addEventListener("click", () => {
  modal?.close();
});

modal?.addEventListener("click", (event) => {
  const rect = modal.querySelector(".modal-card").getBoundingClientRect();
  const clickedOutside =
    event.clientX < rect.left ||
    event.clientX > rect.right ||
    event.clientY < rect.top ||
    event.clientY > rect.bottom;

  if (clickedOutside) {
    modal.close();
  }
});
