# Ace AI Portfolio

A clean one page portfolio site for Ace Perkins.

## Purpose

This site is designed to be a public front porch for private AI work.

It explains Ace's work as an AI workflow builder, app maker, and practical systems designer without exposing private app data, private reflections, confidential business information, or personal content.

## Included files

- `index.html`
- `styles.css`
- `script.js`
- `README.md`

## Quick setup

1. Create a new GitHub repository named `ace-ai-portfolio`.
2. Upload these files to the root of the repository.
3. Go to repository Settings.
4. Open Pages.
5. Under Build and deployment, choose:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /root
6. Save.
7. GitHub will publish the site.

Your public link will usually look like:

`https://YOUR-GITHUB-USERNAME.github.io/ace-ai-portfolio/`

## Before sending the link

Update these items:

1. Replace the AP photo placeholder with Ace's real photo if desired.
2. Review the contact email in `index.html` and `script.js`.
3. Add live links only when they are safe to share.
4. Do not connect the real private Levrynn database.
5. Use sample data only for any public demo.

## Safe demo guidance

For Levrynn or any private app:

- Use fake sample anchors.
- Use fake journal entries.
- Use fake transcripts.
- Use fake audio placeholders.
- Do not expose private Supabase tables.
- Do not expose personal reflections.
- Do not expose private API keys.
- Do not expose customer or company data.

## Suggested next upgrade

Add a `/demo` page showing a fake Levrynn guest mode with sample cards, sample transcript, and sample app flow.
